package com.wipro.service;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.wipro.dao.LoginDAO;
import com.wipro.dbutil.DBUtil;

/**
 * Servlet implementation class loginServlet
 */
@WebServlet(description = "Received requests from the jsp page", urlPatterns = { "/loginServlet" })
public class loginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public loginServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		response.setContentType("text/html");
		Connection conn=DBUtil.getDBConnection();
		
		//request.setAttribute("message","Login is Successfull");
		String username=request.getParameter("username");
		String password=request.getParameter("password");
		if(username.equals("admin01") && password.equals("AdminPass01@")) {
			request.setAttribute("userType","admin");
			request.getRequestDispatcher("/Home.jsp").forward(request, response);
		}
		else 
		{int count=0;
			ResultSet rst=null;
			try {
			PreparedStatement psmt=conn.prepareStatement("select * from userdetails where UserId=? and Password=?;");
			psmt.setString(1,username);
		
				psmt.setString(2,password);
			rst=psmt.executeQuery();
			while(rst.next()){
				count=1;
			}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			if(count==1) {
				request.getRequestDispatcher("/Home.jsp").include(request, response);
			}
			else {
			request.setAttribute("error","Invalid Login credentials");
		request.getRequestDispatcher("/Login.jsp").forward(request, response);
		System.out.println(""+request.getParameter("username"));
		System.out.println(new LoginDAO().getLoginDao());
			}}}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
