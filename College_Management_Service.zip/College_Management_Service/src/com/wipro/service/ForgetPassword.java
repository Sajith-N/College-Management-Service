package com.wipro.service;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class ForgetPassword
 */
@WebServlet("/ForgetPassword")
public class ForgetPassword extends HttpServlet {
	private static final long serialVersionUID = 1L;
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ForgetPassword() {
        super();
        // TODO Auto-generated constructor stub
    }
	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
response.setContentType("text/html");
String userid=request.getParameter("userId");
String petname=request.getParameter("petname");
int len = petname.length();
int tmp=0;
if(userid.length()==0) {
	System.out.println("test2");
	tmp=1;
}
for (int i = 0; i < len; i++) {
   if ((Character.isLetter(petname.charAt(i)) == false)) {
	   System.out.println("test0");
	   tmp=1;
      break;
   }
}
if(tmp==1) {
	System.out.println("test1");
	request.setAttribute("p1","User Id/Security answer is invalid");
	request.getRequestDispatcher("/ForgottenPassword.jsp").forward(request, response);
}
request.setAttribute("check","true");
request.getRequestDispatcher("/ForgottenPassword.jsp").forward(request, response);	
}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
