create table userdetails (UserId varchar(50),Name varchar(50),Age varchar(50),Password varchar(50),petname varchar(50),Gender varchar(50),Department varchar(50),Semester varchar(50));
insert into userdetails values  ('811085','Lohith','28','Madndy','Ashiya','Female','Computer Science','Semester - 03');
select * from userdetails;

create table master (Semester varchar(50),
Department varchar(50),
CourseId varchar(50),
CourseName varchar(50));
insert into master values('Semester - 01','Computer Science','CS101','Mathematics-1');
insert into master values('Semester - 01','Computer Science','CS102','Basic Electrical and Electronics');
insert into master values('Semester - 01','Computer Science','CS103','Engineering graphics');
insert into master values('Semester - 01','Information and Technology','IT101','Mathematics-1');
insert into master values('Semester - 01','Information and Technology','IT102','Basic Electrical and Electronics');
insert into master values('Semester - 01','Information and Technology','IT103','Engineering graphics');
insert into master values('Semester - 02','Computer Science','CS201','Engineering Physics');
insert into master values('Semester - 02','Computer Science','CS202','Basic Mechanical Engineering');
insert into master values('Semester - 02','Computer Science','CS203','Basic Computer Engineering');
insert into master values('Semester - 02','Information and Technology','IT201','Engineering Physics');
insert into master values('Semester - 02','Information and Technology','IT202','Basic Mechanical Engineering');
insert into master values('Semester - 02','Information and Technology','IT203','Basic Computer Engineering'); 
insert into master values('Semester - 03','Computer Science','CS301','Mathematics-3');
insert into master values('Semester - 03','Computer Science','CS302','Electronic Devices and Circuits');
insert into master values('Semester - 03','Computer Science','CS303','Digital Circuits and Design');
insert into master values('Semester - 03','Information and Technology','IT301','Mathematics-3');
insert into master values('Semester - 03','Information and Technology','IT302','Digital Circuits and Systems');
insert into master values('Semester - 03','Information and Technology','IT303','Object Oriented Programming');
