package com.wipro.dbutil;

import java.sql.Connection;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.support.incrementer.H2SequenceMaxValueIncrementer;

import com.wipro.service.H2ConnectionConfig;


public class DBUtil {
/* private static final Logger logger = LoggerFactory.getLogger(DBUtil.class);
	

   H2ConnectionConfig h2ConnectionConfig = new H2ConnectionConfig();
	public Connection getDBConnection() {
		Connection conn=null;
		try {
			logger.debug("Invoking Connection using h2 config class",conn);
			conn = null;
			logger.debug("Invoked Connection using h2 config class",conn);
		} catch (Exception e1) {
				logger.error("Exception in DButil Form", e1);
		}
		return conn;
		}		
	*/}

