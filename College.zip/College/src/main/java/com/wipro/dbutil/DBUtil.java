package com.wipro.dbutil;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.sql.DataSource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.mysql.cj.jdbc.Driver;
import com.wipro.configuration.H2ConnectionConfig;


public class DBUtil {
	H2ConnectionConfig h2ConnectionConfig = new H2ConnectionConfig();
	public Connection getDBConnection() {
		Connection conn=null;
		try {
			conn = h2ConnectionConfig.dataSource().getConnection();
			} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}

		return conn;
	}
}
