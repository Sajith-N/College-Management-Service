package com.wipro.service;

import javax.sql.DataSource;
//import org.slf4j.Logger;
//import org.slf4j.LoggerFactory;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;
import org.springframework.jdbc.datasource.embedded.EmbeddedDatabase;
import org.springframework.jdbc.datasource.embedded.EmbeddedDatabaseBuilder;
import org.springframework.jdbc.datasource.embedded.EmbeddedDatabaseType;

@Profile("h2")
@Configuration
public class H2ConnectionConfig {
//	private static final Logger logger = LoggerFactory.getLogger(H2ConnectionConfig.class);
	/*
	 * @Bean(name="dataSource") public DataSource dataSource() {
	 * DriverManagerDataSource dataSource = new DriverManagerDataSource();
	 * dataSource.setDriverClassName("org.h2.Driver"); dataSource.setUrl(
	 * "jdbc:h2:tcp://localhost/~/test;DB_CLOSE_ON_EXIT=TRUE;FILE_LOCK=NO");
	 * dataSource.setUsername("sa"); dataSource.setPassword(""); return dataSource;
	 * }
	 */
	/*@Bean
	public DataSource dataSource() {
		// no need shutdown, EmbeddedDatabaseFactoryBean will take care of this
		EmbeddedDatabaseBuilder builder = new EmbeddedDatabaseBuilder();
	    EmbeddedDatabase db = builder.setType(EmbeddedDatabaseType.H2).addScript("schema.sql")// .H2 or .DERBY
					.build();
		logger.debug("In Datasource Function with buliding scripts"+db);
		System.out.println("Inside if block"+db);
		return db;
	}*/
}
