package com.wipro.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import com.wipro.dao.RegisterDAO;
import com.wipro.model.Course;
import com.wipro.model.Register;

public class RegisterServiceImpl implements RegisterService {

	@Autowired
	RegisterDAO registerDAO;

	@Override
	public Register getStudent(String userID) {
		return registerDAO.getStudent(userID);
	}

	@Override
	public List<Register> getAllStudents() {
		return registerDAO.getAllStudents();
	}

	@Override
	public int addStudent(Register Register) {
		return registerDAO.addStudent(Register);
	}

	@Override
	public int updateStudent(Register Register) {
		return registerDAO.updateStudent(Register);
	}

	@Override
	public int deleteStudent(String userID) {
		return registerDAO.deleteStudent(userID);
	}

	@Override
	public List<Course> getCourses(String Department, String Semester) {
		return registerDAO.getCourses(Department, Semester);
	}

}
