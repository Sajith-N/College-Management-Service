package com.wipro.service;

import java.util.List;

import com.wipro.model.Course;
import com.wipro.model.Register;

public interface RegisterService {

	public List<Course> getCourses(String Department,String Semester);
	public Register getStudent(String userID);
	public List<Register> getAllStudents();
	public int addStudent(Register Register);
	public int updateStudent(Register Register);
	public int deleteStudent(String userID);	
}
