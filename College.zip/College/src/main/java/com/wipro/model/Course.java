package com.wipro.model;

public class Course {
String name,Department,Semester,UserId;

public String getName() {
	return name;
}

public void setName(String name) {
	this.name = name;
}

public String getDepartment() {
	return Department;
}

public void setDepartment(String department) {
	Department = department;
}

public String getSemester() {
	return Semester;
}

public void setSemester(String semester) {
	Semester = semester;
}

public String getUserId() {
	return UserId;
}

public void setUserId(String userId) {
	UserId = userId;
}
}
