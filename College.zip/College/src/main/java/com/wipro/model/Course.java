package com.wipro.model;

public class Course {
String CourseName,Department,Semester,CourseID;

public Course()
{
	
}
public Course(String courseName, String department, String semester, String courseID) {
	super();
	CourseName = courseName;
	Department = department;
	Semester = semester;
	CourseID = courseID;
}

public String getCourseName() {
	return CourseName;
}

public void setCourseName(String courseName) {
	CourseName = courseName;
}

public String getDepartment() {
	return Department;
}

public void setDepartment(String department) {
	Department = department;
}

public String getSemester() {
	return Semester;
}

public void setSemester(String semester) {
	Semester = semester;
}

public String getCourseID() {
	return CourseID;
}

public void setCourseID(String courseID) {
	CourseID = courseID;
}

}
