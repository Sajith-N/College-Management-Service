package com.wipro.model;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;
import org.hibernate.validator.constraints.Length;
import org.hibernate.validator.constraints.Range;
import org.springframework.stereotype.Component;

@Component
public class Register {
	
	@NotBlank(message = "User Id is mandatory")
	@Pattern(regexp = "^[a-zA-Z0-9]*$", message="User Id must be alphanumeric and should contain 6 - 10 character")
	@Length(min = 6,max = 10,message=" User Id must be alphanumeric and should contain 6 - 10 character")
	String userId=null;

	@NotBlank(message="Password is mandatory")
    @Pattern(regexp = "^(?=.*[A-Z])(?=.*[a-z])(?=.*\\d).*$", message="Password must contain at least one number, one special character, one uppercase, one lowercase letter, one special char and should contain 8 - 16 characters")
	@Length(min = 8,max = 16, message = "Password must contain at least one number, one special character, one uppercase, one lowercase letter, one special char and should contain 8 - 16 characters")
	String password=null;
	

	public Register(String userId,String password,String name,String petname,int age, String gender, String department, String semester) {
		this.userId = userId;
		this.password = password;
		this.name = name;
		this.petname = petname;
		this.age = age;
		this.gender = gender;
		this.department = department;
		this.semester = semester;
	}
	@NotBlank(message="Name is mandatory")
	@Pattern(regexp = "^[a-zA-Z]+$",message = "Name must contain letters only")
	@Length(min = 3,max = 20, message = "Name must be at least 3 - 20 characters long")
	String name=null;

	@NotBlank(message="petname is mandatory")
	@Pattern(regexp = "^[a-zA-Z]+$",message = "Pet Name must contain letters only")
	@Length(min = 3,max = 10, message = "Pet Name must be at least 3 - 10 characters long")	
	String petname=null;

	@NotBlank(message="Age is mandatory")
	@Range(min=18, max=120,message="Age should be greater than 18 and less than 120")	
    int age=0;

String gender;
String department;
String semester;
public String getSemester() {
	return semester;
}
public void setSemester(String semester) {
	this.semester = semester;
}
public Register() {
}
public String getUserId() {
	return userId;
}
public void setUserId(String userId) {
	this.userId = userId;
}
public String getPassword() {
	return password;
}
public void setPassword(String password) {
	this.password = password;
}
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public String getPetname() {
	return petname;
}
public void setPetname(String petname) {
	this.petname = petname;
}
public int getAge() {
	return age;
}
public void setAge(int age) {
	this.age = age;
}
public String getGender() {
	return gender;
}
public void setGender(String gender) {
	this.gender = gender;
}
public String getDepartment() {
	return department;
}
public void setDepartment(String department) {
	this.department = department;
}

}
