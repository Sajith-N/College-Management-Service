package com.wipro.controller;

import java.util.ArrayList;
import java.util.List;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.method.annotation.SessionAttributesHandler;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.mysql.cj.xdevapi.RemoveStatement;
import com.wipro.model.Course;
import com.wipro.model.Register;
import com.wipro.service.RegisterServiceImpl;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@Controller
@SessionAttributes("userType")
public class StudentController {

	private static final Logger logger = LoggerFactory.getLogger(StudentController.class);

	@Autowired
	RegisterServiceImpl registerServiceImpl;

	@RequestMapping(value = "/login", method = RequestMethod.GET)
	public String LoginView(Model model,@ModelAttribute String userType) {
		model.addAttribute("message",userType);
		return "Login";
	}

	@RequestMapping(value = "/studentlist", method = RequestMethod.GET)
	public String studentView(ModelMap model) {
		List<Register> list = registerServiceImpl.getAllStudents();
		logger.error("List length", list.isEmpty());
		model.addAttribute("list", list);
		logger.error("received list", list.size());
		return "Student";
	}

	@RequestMapping(value = "/register", method = RequestMethod.GET)
	public String RegisterView(ModelMap model, Register register) {
		model.addAttribute("register", new Register());
		return "Registration";
	}

	@RequestMapping(value = "/CourseResult", method = RequestMethod.GET)
	public String CourseResultView(ModelMap model, @RequestParam String Department, @RequestParam String Semester) {
		List<Course> course = registerServiceImpl.getCourses(Department, Semester);
		logger.error("List length", course.isEmpty());
		model.addAttribute("list", course);
		return "CourseResult";
	}

	@RequestMapping(value = "/delete", method = RequestMethod.GET)
	public String deleteStudent(@RequestParam String d) {
		registerServiceImpl.deleteStudent(d);
		return "Student";
	}

	@RequestMapping(value = "/register", method = RequestMethod.POST)
	public String RegisteringForm(ModelMap model, @Valid @ModelAttribute("register") Register register,
			BindingResult result,RedirectAttributes attributes) {
		if(register.getUserId().length()==0) {
			model.addAttribute("error","User Id is mandatory");
			return "Registration";
		}
		else if(register.getName().length()==0) {
			model.addAttribute("error","Name is mandatory");	
			return "Registration";
		}
		else if(register.getPassword().length()==0) {
			model.addAttribute("error","Password is mandatory");	
			return "Registration";
		}
		else if(register.getAge()==0) {
			model.addAttribute("error","Age is mandatory");	
			return "Registration";
		}
		
		else if(register.getPetname().length()==0) {
			model.addAttribute("error","Petname is mandatory");	
			return "Registration";
		}
		if (result.hasErrors()) {
			return "Registration";
		}
		String userID = register.getUserId();
		String Name = register.getName();
		int Age = register.getAge();
		String word = register.getPassword();
		String Gender = register.getGender();
		String Department = register.getDepartment();
		String Semester = register.getSemester();
		String petname = register.getPetname();
		Register registerClass = registerServiceImpl.getStudent(userID);
		if (registerClass != null) {
			System.out.println("Register Test4");
			model.addAttribute("error", "User already exists");
			return "Registration";
		}
		registerClass = new Register();
		registerClass.setAge(Age);
		registerClass.setDepartment(Department);
		registerClass.setGender(Gender);
		registerClass.setPassword(word);
		registerClass.setUserId(userID);
		registerClass.setName(Name);
		registerClass.setSemester(Semester);
		registerClass.setPetname(petname);
		int flag = registerServiceImpl.addStudent(registerClass);
		if (flag > 0) {
			attributes.addFlashAttribute("userType", "User successfully registered. Login to continue");
			return "redirect:login";
		}
		return "Register";
	}

	@RequestMapping(value = "/forgotpassword", method = RequestMethod.GET)
	public String forgotPasswordView(ModelMap model) {
		model.addAttribute("check", "");
		return "ForgottenPassword";
	}

	@RequestMapping(value = "/resetpassword", method = RequestMethod.POST)
	public String resetPasswordView(ModelMap model, @RequestParam("password") String word,
			@RequestParam("confirmPassword") String confirmword,RedirectAttributes attributes) {
			attributes.addFlashAttribute("userType", "User successfully registered. Login to continue");
			return "redirect:login";
	}

	@RequestMapping(value = "/forgotpassword", method = RequestMethod.POST)
	public String forgotPasswordFormView(ModelMap model, HttpServletRequest request,
			@RequestParam("userId") String userId, @RequestParam("petname") String petname) {
		Register register = new Register();
		if (userId.isEmpty() || petname.isEmpty()) {
			model.addAttribute("error", "User Id/Security answer is invalid");
			model.addAttribute("check", "");
			return "ForgottenPassword";
		}
		register = registerServiceImpl.getStudent(userId);
		if (register == null || !(register.getPetname()).equals(petname)) {
			model.addAttribute("error", "User Id/Security answer is invalid");
			model.addAttribute("check", "");
			return "ForgottenPassword";
		} else {
			model.addAttribute("userId", userId);
			model.addAttribute("petname", petname);
			model.addAttribute("check", "passed");
			return "ForgottenPassword";
		}
	}

	@RequestMapping(value = "/home", method = RequestMethod.GET)
	public String Home(ModelMap model,@ModelAttribute("userType") String userType,HttpServletRequest request, HttpServletResponse response) {
		System.out.println("Session value "+userType);
		request.setAttribute("userType",userType);
		return "Home";
	}

	@RequestMapping(value = "/login", method = RequestMethod.POST)
	public String LoginSubmitForm(@RequestParam String userId, @RequestParam String password,
			HttpServletRequest request, HttpServletResponse response, Model model,RedirectAttributes attributes) {
		Register register = registerServiceImpl.getStudent(userId);
		if (userId.equals("admin01") && password.equals("AdminPass01@")) {
			attributes.addFlashAttribute("userType","admin");
			return "redirect:home";
		} else {
			if (register == null || password.equals(register.getPassword())) {
				model.addAttribute("error", "Invalid Login credentials");
				return "Login";
			} else {
				attributes.addFlashAttribute("userType", "");
				return "redirect:home";
			}
		}
	}

	@RequestMapping(value = "/coursesearch", method = RequestMethod.GET)
	public String CourseSearchView(@ModelAttribute("userType") String userType,HttpServletRequest request) {
		request.setAttribute("userType",userType);
		return "CourseSearch";
	}

	@RequestMapping(value = "/Test", method = RequestMethod.GET)
	public String TestView() {
		return "Test";
	}

	@ModelAttribute("genderList")
	public List<String> getGenderList() {
		List<String> genderList = new ArrayList<String>();
		genderList.add("Male");
		genderList.add("Female");
		return genderList;
	}

	@ModelAttribute("departmentList")
	public List<String> getDepartmentList() {
		List<String> departmentList = new ArrayList<String>();
		departmentList.add("Computer Science");
		departmentList.add("Information and Technology");
		return departmentList;
	}

	@ModelAttribute("semesterList")
	public List<String> getSemesterList() {
		List<String> semesterList = new ArrayList<String>();
		semesterList.add("Semester - 01");
		semesterList.add("Semester - 02");
		semesterList.add("Semester - 03");
		return semesterList;
	}
}
