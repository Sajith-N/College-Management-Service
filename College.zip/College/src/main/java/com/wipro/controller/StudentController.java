package com.wipro.controller;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.validation.Valid;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;
import com.wipro.dbutil.DBUtil;
import com.wipro.model.Course;
import com.wipro.model.Register;

@Controller
public class StudentController {

	@RequestMapping(value = "/login", method = RequestMethod.GET)
	public String LoginView() {
		return "Login";
	}

	@RequestMapping(value = "/Student", method = RequestMethod.GET)
	public String studentView(ModelMap model) {
		Connection conn = new DBUtil().getDBConnection();
		System.out.println("connection : " + conn);
		PreparedStatement psmt = null;
		List<Course> list = new ArrayList<Course>();
		Course cs = null;
		try {
			psmt = conn.prepareStatement("select name,Department,Semester,UserId from userdetails;");
			ResultSet rs = psmt.executeQuery();

			while (rs.next()) {
				cs = new Course();
				cs.setName(rs.getString(1));
				System.out.println(rs.getString(1));
				cs.setDepartment(rs.getString(2));
				System.out.println(rs.getString(2));
				cs.setSemester(rs.getString(3));
				System.out.println(rs.getString(3));
				cs.setUserId(rs.getString(4));
				System.out.println(rs.getString(4));
				list.add(cs);
			}
			conn.close();

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		model.addAttribute("list", list);
		return "Student";
	}

	@RequestMapping(value = "/Register", method = RequestMethod.GET)
	public String RegisterView(ModelMap model, Register register) {
		model.addAttribute("register", new Register());
		return "Register";
	}

	@RequestMapping(value = "/CourseResult", method = RequestMethod.GET)
	public String CourseResulView(ModelMap model, @RequestParam String Department, @RequestParam String Semester) {
		return "CourseResult";
	}

	@RequestMapping(value = "/delete", method = RequestMethod.GET)
	public String deleteStudent(@RequestParam String d) {
		System.out.println("Inside delete controller " + d);
		return "Delete";
	}

	@RequestMapping(value = "/RegisterForm", method = RequestMethod.POST)
	public String RegisteringForm(ModelMap model, @Valid Register register, BindingResult result) {
		System.out.println("Field has any errors : " + result.hasErrors());
		if (result.hasErrors())
			return "Register";
		String userID = register.getUserId();
		String Name = register.getName();
		int Age = register.getAge();
		String Password = register.getPassword();
		String Gender = register.getGender();
		String Department = register.getDepartment();
		String Semester = register.getSemester();
		String petname = register.getPetname();
		System.out.println(" " + userID + " " + Name + " " + Age + " " + Password + " " + Gender + " " + Department
				+ " " + Semester + " " + petname);
		Connection conn = new DBUtil().getDBConnection();

		try {

			PreparedStatement psmt = conn.prepareStatement("select * from userdetails where  UserId=?;");
			psmt.setString(1, userID);
			ResultSet rst = psmt.executeQuery();
			if (rst.next()) {
				model.addAttribute("error", "User already exists");
				return "Register";
			}
			psmt = conn.prepareStatement("insert into userdetails values  (?,?,?,?,?,?,?,?);");
			psmt.setString(1, userID);
			psmt.setString(2, Name);
			psmt.setInt(3, Age);
			psmt.setString(4, Password);
			psmt.setString(5, petname);
			psmt.setString(6, Gender);
			psmt.setString(7, Department);
			psmt.setString(8, Semester);
			int flag = psmt.executeUpdate();
			System.out.println("Data insertion " + flag);
			conn.close();
			if (flag > 0) {
				model.addAttribute("message", "User successfully registered. Login to continue");
				return "Login";
			}
		} catch (SQLException e) {
// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return "Register";
	}

	@RequestMapping(value = "/ForgottenPassword", method = RequestMethod.GET)
	public String forgotPasswordView(ModelMap model) {
		model.addAttribute("check","");
		return "ForgottenPassword";
	}

	@RequestMapping(value = "/ForgottenPasswordForm", method = RequestMethod.POST)
	public String forgotPasswordFormView(ModelMap model,HttpServletRequest request,@RequestParam("userId") String userId,@RequestParam("petname") String petname) {		
		System.out.println("Inside Forgot password form"+userId+" "+petname);
		Connection conn = new DBUtil().getDBConnection();
		try {
		PreparedStatement psmt=conn.prepareStatement("select * from userdetails where userid=? and petname=?");
psmt.setString(1,userId);
psmt.setString(2,petname);		
ResultSet rst=psmt.executeQuery();
conn.close();
		while(rst.next()) {
			request.setAttribute("check", true);
			return "ForgottenPassword";
	}}catch (Exception e) {
		// TODO: handle exception
	}
		model.addAttribute("p1", "User Id/Security answer is invalid");
		return "ForgottenPassword";
		}
		

	@RequestMapping(value = "/CourseSearch", method = RequestMethod.GET)
	public String CourseSearchView() {
		return "CourseSearch";
	}

	@RequestMapping(value = "/Test", method = RequestMethod.GET)
	public String TestView() {
		return "Test";
	}

	@RequestMapping(value = "/LoginForm", method = RequestMethod.POST)
	public String LoginSubmitForm(@RequestParam String username, @RequestParam String password,
			HttpServletRequest request, HttpServletResponse response) {
		ModelAndView model = new ModelAndView();
		Connection conn = new DBUtil().getDBConnection();
		if (username.equals("admin01") && password.equals("AdminPass01@")) {
			request.setAttribute("userType", "admin");
			return "Home";
		} else {
			int count = 0;
			ResultSet rst = null;
			try {
				PreparedStatement psmt = conn
						.prepareStatement("select * from userdetails where UserId=? and Password=?;");
				psmt.setString(1, username);
				psmt.setString(2, password);
				rst = psmt.executeQuery();
				while (rst.next()) {
					count = 1;
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			if (count == 1) {
				request.setAttribute("userType", "");
				return "Home";
			} else {
				model.addObject("error", "Invalid Login credentials");
				return "Login";
			}
		}
	}

	@ModelAttribute("genderList")
	public List<String> getGenderList() {
		List<String> genderList = new ArrayList<String>();
		genderList.add("Male");
		genderList.add("Female");
		return genderList;
	}

	@ModelAttribute("departmentList")
	public List<String> getDepartmentList() {
		List<String> departmentList = new ArrayList<String>();
		departmentList.add("Computer Science");
		departmentList.add("Information and Technology");
		return departmentList;
	}

	@ModelAttribute("semesterList")
	public List<String> getSemesterList() {
		List<String> semesterList = new ArrayList<String>();
		semesterList.add("Semester - 01");
		semesterList.add("Semester - 02");
		semesterList.add("Semester - 03");
		return semesterList;
	}
}
