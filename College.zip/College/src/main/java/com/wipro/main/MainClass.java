package com.wipro.main;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.wipro.dao.RegisterDAOImpl;
import com.wipro.model.Register;

public class MainClass {
public static void main(String[] args) {
/*	RegisterDAOImpl registerdao=new RegisterDAOImpl();
Register register=new Register();
register.setAge(25);
register.setDepartment("Computer Science");
register.setSemester("Semester - 01");
register.setGender("Male");
register.setUserId("811085232");
register.setName("Sajith Reddy");
register.setPetname("Sajith");
register.setPassword("AmmaNana@15");
	int count=registerdao.addStudent(register);

System.out.println("Rows inserted "+registerdao.getAllStudents().size());	
*/	
}
}
