/**
 * 
 */
/**
 * @author 23554
 *
 */
package com.wipro.main;

class MainClient{
	public static void main(String[] args) {
	System.out.println("In Main class");
	}
}