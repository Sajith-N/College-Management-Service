package com.wipro.dao;

import java.sql.ResultSet;
import java.sql.SQLException;

//import org.slf4j.Logger;
//import org.slf4j.LoggerFactory;
import org.springframework.jdbc.core.RowMapper;

import com.wipro.model.Course;
import com.wipro.model.Register;

public class CourseRowMapper implements RowMapper<Course> {
	//private static final Logger logger = LoggerFactory.getLogger(CourseRowMapper.class);
	
	@Override
	public Course mapRow(ResultSet rs, int rowNum) throws SQLException {
		//logger.debug("Inside Course row mapper class");
		Course course = new Course();
		course.setCourseID(rs.getString("CourseId"));
		course.setCourseName(rs.getString("CourseName"));
		course.setSemester(rs.getString("Semester"));
		course.setDepartment(rs.getString("Department"));
		return course;
	}}
