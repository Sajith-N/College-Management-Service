package com.wipro.dao;

import java.util.ArrayList;
import java.util.List;

import com.wipro.model.Course;
import com.wipro.model.Register;
	
public interface RegisterDAO {

	public static ArrayList<Register> register=new ArrayList<Register>();
	public List<Course> getCourses(String Department,String Semester);
	public Register getStudent(String userID);
	public List<Register> getAllStudents();
	public int addStudent(Register Register);
	public int updateStudent(Register Register);
	public int deleteStudent(String userID);	
}
