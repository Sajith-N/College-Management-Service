package com.wipro.dao;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.transaction.annotation.Transactional;

import com.wipro.model.Course;
import com.wipro.model.Register;


public class RegisterDAOImpl implements RegisterDAO {

	

	@Autowired
	private JdbcTemplate jdbcTemplate;

	public Register getStudent(String userID) {
		System.out.println("Register Size"+register.size());
		for (Register r : register)
			if (userID.equals(r.getUserId())) {
				System.out.println("registered use"+userID);
				return r;
			}
		return null;
	}

	public List<Register> getAllStudents() {
		return register;
	}

	@Transactional
	public int addStudent(Register registe) {
		register.add(registe);
	System.out.println("Register Size"+register.size());
		return register.size();
	}

	public int updateStudent(Register tmp) {
		System.out.println("Register Size"+register.size());
		int c = 0;
		for (Register e : register) {
			if (tmp.getUserId().equals(e.getUserId())) {
				c = 1;
				register.remove(e);
				register.add(tmp);
				break;
			}
		}
		return c;
	}

	public int deleteStudent(String userID) {
		int c = 0;
		for (Register e : register) {
			if (userID.equals(e.getUserId())) {
				c = 1;
				register.remove(e);
				break;
			}
		}
		return c;

	}

	@Transactional
	public List<Course> getCourses(String Department, String Semester) {
		List<Course> course = jdbcTemplate.query("select * from master where Department=? and semester=?;",
				new Object[] { Department, Semester }, new CourseRowMapper());
		return course;
	}

}
