package com.wipro.dao;

import java.sql.ResultSet;
import java.sql.SQLException;

//import org.slf4j.Logger;
//import org.slf4j.LoggerFactory;
import org.springframework.jdbc.core.RowMapper;

import com.wipro.controller.StudentController;
import com.wipro.model.Register;

public class RegisterRowMaper implements RowMapper<Register> {
	//private static final Logger logger = LoggerFactory.getLogger(RegisterRowMaper.class);
	
	@Override
	public Register mapRow(ResultSet rs, int rowNum) throws SQLException {
		//logger.debug("Inside register row mapper class");
		Register register = new Register();
		register.setUserId(rs.getString("UserId"));
		register.setPassword(rs.getString("Authentication_key"));
		register.setDepartment(rs.getString("Department"));
		register.setSemester(rs.getString("Semester"));
		register.setPetname(rs.getString("petname"));
		register.setAge(rs.getInt("Age"));
		register.setGender(rs.getString("Gender"));
		register.setName(rs.getString("Name"));
		return register;
	}

}
