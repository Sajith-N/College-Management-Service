package com.wipro.courier.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

@Controller
public class OrdersController {

	@RequestMapping(value="/addOrders",method=RequestMethod.GET)
	public String addOrdersPage(ModelMap model) {
		return null;
	}
	@RequestMapping(value="/addOrders",method=RequestMethod.POST)
	public String removeOrdersPage(ModelMap model) {
		return null;
	}
	
	@ModelAttribute("orderStatus")
	public List<String> getStatusList() {
		List<String> odrStatus = new ArrayList<String>();
		odrStatus.add("Open");
		odrStatus.add("Cancelled");
		odrStatus.add("Delivered");
	return odrStatus;
	}
	@ModelAttribute("stateList")
	public List<String> getGenderList() {
		List<String> stateList = new ArrayList<String>();
		stateList.add("Andhra Pradesh");
		stateList.add("Arunachal Pradesh");
		stateList.add("Assam");
		stateList.add("Bihar");
		stateList.add("Chhattisgarh");
		stateList.add("Goa");
		stateList.add("Gujarat");
		stateList.add("Haryana");
		stateList.add("Himachal Pradesh");
		stateList.add("Jammu & Kashmir");
		stateList.add("Jharkhand");
		stateList.add("Karnataka");
		stateList.add("Kerala");
		stateList.add("Madhya Pradesh");
		stateList.add("Maharashtra");
		stateList.add("Manipur");
		stateList.add("Meghalaya");
		stateList.add("Mizoram");
		stateList.add("Nagaland");
		stateList.add("Odisha");
		stateList.add("Punjab");
		stateList.add("Rajasthan");
		stateList.add("Sikkim");
		stateList.add("Tamil Nadu");
		stateList.add("Telangana");
		stateList.add("Tripura");
		stateList.add("Uttarakhand");
		stateList.add("Uttar Pradesh");
		stateList.add("West Bengal");
		return stateList;
	}
}
